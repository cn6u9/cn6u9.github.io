/*
<T>XDB</T>
<X>
com.microsoft.sqlserver.jdbc.SQLServerDriver
jdbc:sqlserver://127.0.0.1:1433;databaseName=test;user=sa;password=123456
</X>
*/

module.exports = require('./default');