
# 更新内容

1.优化 subfinder key调用逻辑<br />
2.新增 -fofa -quake -hunter 模式，允许输入四种类型数据：公司名，根域名，ip 或者cidr<br />
3.添加大量指纹<br />
4.修改Nuclei 对模板的限制（原dddd项目下好多人说自己添加的poc不能使用就是这个问题）<br />
5.持续维护poc<br />
<br />
2025.5.19 更新修复mysql爆破失败的问题<br />

添加微信进群获取<br />


![vx](https://github.com/user-attachments/assets/5b6a44a1-a397-4f3e-8f73-0553fadf8f18)
